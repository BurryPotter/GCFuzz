# Readme

如果源码中包含 

* random相关

  将random变量删除，需要随机数的位置用一个固定值代替

* bean相关

  直接将源码删除，不进行编译

* time相关

  将time有关的变量删除

* 使用math包

  将完整的类名（包名+类名）写到文件skipclass.txt下

* 与Thread有关

  将完整的类名（包名+类名）写到文件skipclass.txt下