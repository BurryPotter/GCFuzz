package Bug_triggering_input.Compiler_triggering_input.JDK_8058847;
public class EliminateAutoBoxCrash {
    private static final int[] values = new int[256];

    public static void main(String[] args) {
        byte[] bytes = new byte[] {-1};
        while (true) {
            for (Byte b : bytes) {
                values[b & 0xff]++;
            }
        }
    }
}
