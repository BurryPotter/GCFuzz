package Bug_triggering_input.Compiler_triggering_input.JDK_8036100;
public abstract class Drawable implements DrawableInterface { 
} 