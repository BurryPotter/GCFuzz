package Bug_triggering_input.Compiler_triggering_input.JDK_8036100;
public class Box extends Drawable implements ShadowDrawable { 

} 