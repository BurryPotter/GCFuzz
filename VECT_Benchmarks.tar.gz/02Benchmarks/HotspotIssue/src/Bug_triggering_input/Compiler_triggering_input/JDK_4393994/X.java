package Bug_triggering_input.Compiler_triggering_input.JDK_4393994;
class X {

    public static void main(String args[]) {
      for(int i = 0; i < 1;) {
        i2 = 10;
        i2++;
      }
    }
  
    static int i2;
  }