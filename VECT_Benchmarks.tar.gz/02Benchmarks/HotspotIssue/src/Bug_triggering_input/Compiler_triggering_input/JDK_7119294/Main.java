package Bug_triggering_input.Compiler_triggering_input.JDK_7119294;
public class Main {
    public static void main(String... args) {
        "Hello".substring(0, 4);
    }
}