package Bug_triggering_input.Compiler_triggering_input.JDK_8206963.sub2;

public class T2{
    public static int foo=300;
    public static void change(int newVal) {foo=newVal;}
}