package Bug_triggering_input.Compiler_triggering_input.JDK_8206963.sub1;
import Bug_triggering_input.Compiler_triggering_input.JDK_8206963.sub2.T2;
public class T1{
    public int xadd(int a,int b){
        int r=a+b+T2.foo;
        System.out.println(r);
        return r;
    }
}