package Bug_triggering_input.Compiler_triggering_input.JDK_4411596;
import java.nio.*;


public class InlineBug {

    static int time(String name, ByteBuffer bb) {
int n = bb.capacity();
bb.limit(bb.capacity());
int a = 0;

for (int i = 0; i < 4096; i++) {
bb.rewind();
for (int j = 0; j < n; j++)
a += bb.get(j);
}
System.out.println(name + " " );
return a;
    }

    public static void main(String[] args) {
int n = 4096;
String key = "hd";
if (args.length == 1)
key = args[0];
int a = 0;
if (key.indexOf('h') >= 0)
;
if (key.indexOf('d') >= 0)
;
System.exit(a);
    }

}