package Bug_triggering_input.Compiler_triggering_input.JDK_4338749;
import java.awt.*;
import java.awt.event.*;

class test {

    public static void main(String args[]) {
Frame f = new Frame();
f.setSize(400,400);
f.pack();
f.show();
System.out.println(Toolkit.getDefaultToolkit().getLockingKeyState(KeyEvent.VK_KANA_LOCK));
    }
}