package Bug_triggering_input.Compiler_triggering_input.JDK_8259641;
class Reduced {
  int a;
  int b;
  byte c;
  long e(int f, int g, long h) {
    int i[] = new int[a];
    double j = 2.74886;
    long k[][] = new long[a][a];
    long l = FuzzerUtils.checkSum(k);
    return l;
  }
  void m() {
    int s, o, p[] = new int[a];
    double d;
    for (d = 5; d < 388; d++) {
      e(b, b, 40418347472393L);
      for (s = 3; s < 66; ++s)
        FuzzerUtils.int1array(a, 9);
    }
    for (o = 6; o > 2; o--)
      p[o] = c;
  }
  public static void main(String[] q) {
    Reduced r = new Reduced();
    r.m();
  }
}

