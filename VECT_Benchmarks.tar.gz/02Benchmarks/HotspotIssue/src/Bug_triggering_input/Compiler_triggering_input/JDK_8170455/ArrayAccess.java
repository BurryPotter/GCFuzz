package Bug_triggering_input.Compiler_triggering_input.JDK_8170455;
interface ArrayAccessInterface {
    default int [] arrayAccess() {
        int a[] =new int[10];
        return a.clone();
    }
}
class ArrayAccess implements ArrayAccessInterface {
    public static void main(String args[]){
        int i=0;
        while (i++ < 100000) {
            run();
        }
    }
    public static void run() {
        new ArrayAccess().arrayAccess();
    }

}