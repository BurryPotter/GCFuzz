package Bug_triggering_input.Compiler_triggering_input.JDK_8257574;
/**
 * @test
 *
 * @run main/othervm -Xcomp -XX:CompileOnly=TestInfiniteLoopNotInnerMost::test TestInfiniteLoopNotInnerMost
 *
 */
public class TestInfiniteLoopNotInnerMost {
    public static void main(String[] args) {
        test(false);
    }

    private static void test(boolean flag) {
        if (flag) {
            while (true) {
                for (int i = 1; i < 100; i *= 2) {

                }
            }
        }
    }
}