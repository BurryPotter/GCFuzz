package Bug_triggering_input.Compiler_triggering_input.JDK_4375574;
public class test86 {
    public static void main (String argv[]) {
double d1=0.1;
  double d2=0.2;
System.out.println("d1 = " + d1);
  System.out.println("d2 = " + d2);
     }
 }
