package Bug_triggering_input.Compiler_triggering_input.JDK_6209737;
public class X {
    private static int COUNT = 1000000000;

    public static void main(String[] args) {
        System.out.println("starting");

        for (int i = 0; i < COUNT; i++) { }
        System.out.println();
    }
}