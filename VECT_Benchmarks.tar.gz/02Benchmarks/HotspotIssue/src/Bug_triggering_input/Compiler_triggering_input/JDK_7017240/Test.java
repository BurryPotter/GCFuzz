package Bug_triggering_input.Compiler_triggering_input.JDK_7017240;
public class Test {
    public static void main(String args[]) throws Exception {
        Class initClass = Class.forName("com.sun.tools.hat.internal.oql.OQLEngine");
    }
}