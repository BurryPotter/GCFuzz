package Bug_triggering_input.Compiler_triggering_input.JDK_4964824;
class B {}
public class A {
    public static void main(String[] args) {
        Class c = B.class;
// Class c = B[].class;
    }
}