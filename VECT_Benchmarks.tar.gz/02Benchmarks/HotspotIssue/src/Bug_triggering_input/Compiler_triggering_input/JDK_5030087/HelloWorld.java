package Bug_triggering_input.Compiler_triggering_input.JDK_5030087;
public class HelloWorld {

    public static void main(String argv[]) {
        System.out.println("Hello World");
    }

}