package Bug_triggering_input.Compiler_triggering_input.JDK_8157834;
public class Hello {
    public static void main(String[] args) {
        System.out.println("Hello, World\n");
    }
}