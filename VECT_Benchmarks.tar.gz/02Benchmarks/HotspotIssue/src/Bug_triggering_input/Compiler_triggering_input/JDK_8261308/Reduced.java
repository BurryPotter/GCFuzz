package Bug_triggering_input.Compiler_triggering_input.JDK_8261308;
class Reduced {
  static int N = 400;
  static boolean b;
  static long lArrFld[] = new long[N];
  static int iArrFld[] = new int[N];

  static void test() {
    int i19 = 9, i21 = 8;
    long l1;
    do
      if (!b) {
        iArrFld[1] /= l1 = 1;
        do {
          int i22 = 1;
          do {
            iArrFld[0] = (int)l1;
            iArrFld[i22 - 1] = i21;
          } while (++i22 < 1);
          lArrFld[1] = i21;
        } while (++l1 < 145);
      }
    while (++i19 < 173);
    System.out.println();
  }
  public static void main(String[] strArr) {
      for (int i = 0; i < 10; i++) {
        test();
     }
  }
}
