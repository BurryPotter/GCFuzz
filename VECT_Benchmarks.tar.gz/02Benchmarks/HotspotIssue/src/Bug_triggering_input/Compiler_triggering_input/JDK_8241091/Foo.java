package Bug_triggering_input.Compiler_triggering_input.JDK_8241091;
public class Foo {

    private static int bar(int x) {
        return Integer.bitCount(x);
    }

    public static void main(String[] args) {
        int sum = 0;
        for (int i = 0; i < 30000; i++) {
            sum += bar(i);
        }
        System.out.println(sum);
    }
}