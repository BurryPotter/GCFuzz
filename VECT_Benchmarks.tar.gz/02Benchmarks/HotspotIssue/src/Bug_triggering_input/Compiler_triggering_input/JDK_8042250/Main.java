package Bug_triggering_input.Compiler_triggering_input.JDK_8042250;
public class Main{
    public static void main(String ar[]){
        System.out.println("Hello world");
    }
}