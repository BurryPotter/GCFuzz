package Bug_triggering_input.Compiler_triggering_input.JDK_7032963;
public class test {
    static Object a1;
    static Object a2;
    static Object a3;
    public static void main(String[] args) {
        a1 = args;
        a2 = args;
        a3 = args;
    }
}