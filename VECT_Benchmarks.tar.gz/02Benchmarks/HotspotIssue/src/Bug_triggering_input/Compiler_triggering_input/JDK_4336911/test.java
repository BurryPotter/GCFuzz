package Bug_triggering_input.Compiler_triggering_input.JDK_4336911;
import java.security.*;

public class test {
    public static void main(String args[]) {}
}