package Bug_triggering_input.Compiler_triggering_input.JDK_4344895;
public class Adapters5 {
    int longJohn() {
      return hashCode();
    }
    public static void main(String args[]) {
      Adapters5 adapt = new Adapters5();
      int i000=0,i001=0,i002=0,i003=0,i004=0,i005=0,i006=0,i007=0,i008=0,i009=0;
      int i010=0,i011=0,i012=0,i013=0,i014=0,i015=0,i016=0,i017=0,i018=0,i019=0;
      int i020=0,i021=0,i022=0,i023=0,i024=0,i025=0,i026=0,i027=0,i028=0,i029=0;
      int i030=0,i031=0,i032=0,i033=0,i034=0,i035=0,i036=0,i037=0,i038=0,i039=0;
      int i040=0,i041=0,i042=0,i043=0,i044=0,i045=0,i046=0,i047=0,i048=0,i049=0;
      int i050=0,i051=0,i052=0,i053=0,i054=0,i055=0,i056=0,i057=0,i058=0,i059=0;
      int i060=0,i061=0,i062=0,i063=0,i064=0,i065=0,i066=0,i067=0,i068=0,i069=0;
      int i070=0,i071=0,i072=0,i073=0,i074=0,i075=0,i076=0,i077=0,i078=0,i079=0;
      int i080=0,i081=0,i082=0,i083=0,i084=0,i085=0,i086=0,i087=0,i088=0,i089=0;
      int i090=0,i091=0,i092=0,i093=0,i094=0,i095=0,i096=0,i097=0,i098=0,i099=0;
      long i = 0;
      while(true) {
        adapt.longJohn();
        if (++i % 100000 == 0) {
  System.out.println("Iteration: " + i);
        }
      }
    }
  }