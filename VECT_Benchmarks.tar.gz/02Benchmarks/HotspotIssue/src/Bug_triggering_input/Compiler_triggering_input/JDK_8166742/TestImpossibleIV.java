package Bug_triggering_input.Compiler_triggering_input.JDK_8166742;
public class TestImpossibleIV {

    static private void testMethod() {
        int sum = 0;
        // A unit count-down loop which has an induction variable with
        // MIN_VALUE stride.
        for (int i = 100000; i >= 0; i--) {
            sum += Integer.MIN_VALUE;
        }
    }

    public static void main(String[] args) {
        testMethod();
    }
}
