package Bug_triggering_input.Compiler_triggering_input.JDK_8262017;
class a {
  short b;
}
class Test2 {
  short f(int g, int h) {
    a i = new a();
    for (int j = 0; j < 3; ++j) {
      float k = 9;
      float[] m = new float[2];
      for (int n = 0; n < 5; ++n)
        if (j >= 1)
          if (n <= 1)
            h += k;
      for (int l12 = 0; l12 < 9; ++l12)
        for (int o = 0; o < 1; ++o)
          m[0] *= 0;
    }
    return i.b;
  }
  public static void main(String[] args) {
    Test2 p = new Test2();
    for (int l4 = 0;;)
      p.f(l4, l4);
  }
}

