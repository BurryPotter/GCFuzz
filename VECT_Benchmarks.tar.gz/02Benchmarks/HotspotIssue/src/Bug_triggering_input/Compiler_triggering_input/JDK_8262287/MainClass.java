package Bug_triggering_input.Compiler_triggering_input.JDK_8262287;
class a {
    short b = 2;
    int c = 8;
}
class MainClass {
    a[] d = {new a()};
    a e;
    byte f;
    byte g(int h) {
        a i = new a();
        for (int j = 0; j < 6; ++j) {
            a[] k = {};
            if (i.b < 0101)
                i = e;
            for (int l = 0; l < 9; ++l) {
                a m = new a();
                i = m;
            }
        }
        if (d[0].c > 1)
            for (int n = 0; n < 7; ++n)
                ;
        return f;
    }
    public static void main(String[] args) {
        MainClass o = new MainClass();
        for (int p = 0;;)
            o.g(p);
    }
}
