package Bug_triggering_input.Compiler_triggering_input.JDK_4348052;
import java.util.*;

class test {
   public Vector factor(long num) {
      Vector factors = new Vector();
      double l=0;
      for (double t = 2; t < num; t++) {
         l = (num / t);
         if ( l == Math.round(num / t)) {
            factors.addElement(new Long((long)t));
            System.out.println(t);
         }
      }

      return factors;
   }
   public static void main(String[] args) {
      test t = new test();
      int m_WorkData = 4000013;

      t.factor(m_WorkData);


      //milliseconds
      System.out.println(m_WorkData+ ": Computing time = ");

   }
}
