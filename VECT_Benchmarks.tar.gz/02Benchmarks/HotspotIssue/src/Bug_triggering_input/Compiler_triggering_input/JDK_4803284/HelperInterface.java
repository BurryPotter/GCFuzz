package Bug_triggering_input.Compiler_triggering_input.JDK_4803284;
/**
 * Enables the interface test.
 */
public interface HelperInterface
{
    /**
     * Makes polyHardF() interface-callable.
     */
    void polyHardF (int value);
}