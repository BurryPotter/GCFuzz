package Bug_triggering_input.Compiler_triggering_input.JDK_4803284;
/**
 * Used only to override the polymorphic method.
 */
public class HelperD extends HelperC implements HelperInterface
{
    /**
     * Makes Helper.polyHardF() even more polymorphic.
     */
    public void polyHardF (int value) { x ^= value; }
}