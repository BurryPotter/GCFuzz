package Bug_triggering_input.Compiler_triggering_input.JDK_8256934;
class l {
      double l22;
    }
    class MainClass {
      l[] c;
      double d(int j) {
       int e = 0;
       double a = 7;
       for (int h = 0;
   h < 9;
  ) {
        for (int i = 0;
  i < 6;
  ++i) {
         for (int f = 0;
 f < 9;
 ++f)           a += e = (e * 12 * e);
         if ((boolean)(j >= 1))           ;
       }
        for (int l155 = 0;
  l155 < 2;
  ++l155)         for (int k = 0;
  k < 2;
  ++k)           ;
      }
       return c[0].l22;
     }
      public static void main(String[] args) {
       MainClass b = new MainClass();
       for (int g = 0;
  ;
  )       b.d(g);
     }
    }

