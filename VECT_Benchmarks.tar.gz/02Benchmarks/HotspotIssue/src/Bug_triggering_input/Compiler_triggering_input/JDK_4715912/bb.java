package Bug_triggering_input.Compiler_triggering_input.JDK_4715912;
class foo {
    foo g;
}

class bar {
    void setf(foo f) {
        if (f == null) {
            System.out.println("null");
        } else {
            f.g = f.g;
        }
    }
}

public class bb {
    public static void main(String args[]) {
        bar b = new bar();
        foo f = new foo();
        b.setf(f);
    }
}

