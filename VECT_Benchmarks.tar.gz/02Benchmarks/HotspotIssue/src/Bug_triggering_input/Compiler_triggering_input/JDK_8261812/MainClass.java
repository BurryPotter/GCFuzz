package Bug_triggering_input.Compiler_triggering_input.JDK_8261812;
class Test0 {
    double l1 = (double)33;
    byte l2 = (byte)-17;
    double[] l13 = new double[8];
    double[] l17 = new double[3];
    float[] l33 = new float[2];
    public byte method0() {
        double l0 = (double)48;
        l0 += (double)-11;
        l0 -= (double)(l0 + (43 * l1));
        return l2;
    }

}
public class MainClass {
    Test0[] l14 = new Test0[] {new Test0(), new Test0(), new Test0()};
    Test0 l15 = new Test0();
    Test0 l27 = new Test0();
    Test0 l29 = new Test0();
    Test0[] l42 = new Test0[] {new Test0(), new Test0()};
    public Test0[] method2() {
        int[] l5 = new int[3];
        byte l11 = (byte)-12;
        double[] l18 = new double[8];
        char l22 = (char)27;
        double l26 = (double)-8;
        l5 = (int[])l5;
        if ((boolean)((int[])l5 == (int[])l5)) {
            Test0 l10 = new Test0();
            for (int l6 = 0; l6 < 6; ++l6) {
                for (int l7 = 0; l7 < 7; ++l7) {
                    l5[0] = (int)(39 - l5[0]);
                }
                if ((boolean)((int)l6 > (int)1)) {
                    int l8 = (int)-24;
                    l5 = (int[])l5;
                    l5[0] += (int)l8;
                    l8 *= (int)(l5[0] + (l8 * (l5[0] * l5[0])));
                } else {
                    int l9 = (int)-44;
                    l5[0] -= (int)(((l5[0] - l6) + l9) - (l9 * -3));
                    l9 += (int)-10;
                    l9 *= (int)(((l5[0] - l6) * (l9 * 20)) * (-36 * (l9 * l6)));
                }
                l5[0] *= (int)l5[0];
                if ((boolean)((int)l6 != (int)1)) {
                    l10 = (Test0)l10;
                } else {
                    l10 = (Test0)l10;
                    l11 = (byte)((-6 + (8 + l6)) + ((l10.l1 * l10.l1) * -34));
                }
            }
            l10 = (Test0)l10;
        } else {
            Test0 l12 = new Test0();
            Test0[] l16 = new Test0[] {new Test0(), new Test0(), new Test0(), new Test0(), new Test0(), new Test0()};
            if ((boolean)((Test0)l12 == (Test0)l12)) {
                l12.l13[0] -= (double)(((l12.l13[0] - -14) * l12.l1) * (l12.l1 + l12.l1));
            } else {
                if ((boolean)((Test0[])l14 == (Test0[])l14)) {
                    l5[0] += (int)l14[0].l2;
                    l14[0].l13[0] -= (double)(((-18 * 5) * 40) + l14[0].l1);
                    l15 = (Test0)l12;
                    l11 *= (byte)9;
                } else {
                    l15.l2 *= (byte)l12.l2;
                    l12.l2 -= (byte)l14[0].l2;
                }
                if ((boolean)((double[])l14[0].l13 == (double[])l14[0].l13)) {
                    l16[0] = (Test0)l16[0];
                } else {
                    l16[0].l1 += (double)l16[0].l13[0];
                }
            }
            l5[0] -= (int)((l14[0].l1 - -25) - (-6 + -45));
            if ((boolean)((double)l15.l1 > (int)1)) {
                l14[0].l17 = (double[])l18;
                for (int l19 = 0; l19 < 3; ++l19) {
                    l15.l2 -= (byte)l15.l1;
                    l12.l1 -= (double)((l16[0].l2 + (-2 * -42)) * (8 + (l12.l13[0] * -39)));
                }
            } else {
                l16[0].l2 -= (byte)l15.l2;
            }
        }
        for (int l20 = 0; l20 < 2; ++l20) {
            for (int l21 = 0; l21 < 4; ++l21) {
                Test0 l24 = new Test0();
                l22 = (char)l14[0].l1;
                for (int l23 = 0; l23 < 5; ++l23) {
                    l24 = (Test0)l15;
                }
                for (int l25 = 0; l25 < 3; ++l25) {
                    l15.l1 *= (double)14;
                    l14[0].l1 -= (double)l26;
                    l27 = (Test0)l27;
                    l15 = (Test0)l27;
                }
            }
        }
        return l14;
    }

    public double method1() {
        double[] l34 = new double[4];
        double l45 = (double)47;
        float l49 = (float)15;
        byte[] l50 = new byte[6];
        double l59 = (double)22;
        for (int l4 = 0; l4 < 7; ++l4) {
            Test0[] l28 = new Test0[] {new Test0(), new Test0(), new Test0(), new Test0(), new Test0(), new Test0(), new Test0(), new Test0()};
            Test0 l31 = new Test0();
            char[] l38 = new char[6];
            l28 = method2();
            if ((boolean)((Test0[])l14 == (Test0[])l14)) {
                if ((boolean)((double)l15.l1 == (int)1)) {
                    l15 = (Test0)l28[0];
                } else {
                    l28[0].l2 -= (byte)34;
                    l15 = (Test0)l27;
                    l14[0] = (Test0)l29;
                }
            } else {
                short[] l36 = new short[2];
                for (int l30 = 0; l30 < 7; ++l30) {
                    l14[0].l13[0] -= (double)-14;
                    l28[0] = (Test0)l15;
                    l29 = (Test0)l31;
                    l14[0].l17 = (double[])l28[0].l13;
                }
                for (int l32 = 0; l32 < 2; ++l32) {
                    l28[0].l13 = (double[])l31.l17;
                    l15.l17 = (double[])l31.l17;
                    l15.l13 = (double[])l29.l17;
                }
                if ((boolean)((double)l29.l1 != (int)1)) {
                    l27.l33 = (float[])l29.l33;
                    l29.l13 = (double[])l27.l13;
                    l28[0].l17[0] *= (double)(-29 * 45);
                } else {
                    short[] l35 = new short[4];
                    short l37 = (short)-36;
                    l15.l13 = (double[])l34;
                    l14[0].l1 *= (double)((-7 + (l14[0].l13[0] * -1)) * -31);
                    l35 = (short[])l36;
                    l37 *= (short)(12 + ((46 * -33) + l28[0].l2));
                }
            }
            if ((boolean)((byte)l28[0].l2 <= (int)1)) {
                Test0 l44 = new Test0();
                l27.l17[0] = (double)l14[0].l17[0];
                l38 = (char[])l38;
                for (int l39 = 0; l39 < 0; ++l39) {
                }
                for (int l40 = 0; l40 < 2; ++l40) {
                    short[] l41 = new short[4];
                    int l43 = (int)6;
                    l41 = (short[])l41;
                    l42[0] = (Test0)l31;
                    l43 *= (int)l15.l2;
                    l44 = (Test0)l42[0];
                }
            } else {
                double l46 = (double)30;
                if ((boolean)((int)l4 == (int)1)) {
                    l42[0].l1 -= (double)l42[0].l1;
                    l14[0].l2 += (byte)(((-9 - l28[0].l1) + -38) - (-45 * -30));
                    l34[0] -= (double)-27;
                    l42[0].l17[0] += (double)l45;
                } else {
                    l14[0].l17 = (double[])l14[0].l13;
                    l14[0].l33 = (float[])l28[0].l33;
                    l28[0].l1 += (double)(25 - ((l46 - -46) + (-5 + -17)));
                }
                for (int l47 = 0; l47 < 0; ++l47) {
                }
                l15.l17[0] = (double)(2 + -3);
                for (int l48 = 0; l48 < 9; ++l48) {
                    l45 *= (double)(l34[0] + 16);
                    l31.l33[0] -= (float)(45 * (-48 + l49));
                }
            }
            if ((boolean)((Test0)l27 == (Test0)l27)) {
                l50 = (byte[])l50;
                for (int l51 = 0; l51 < 7; ++l51) {
                    l27 = (Test0)l15;
                    l15 = (Test0)l31;
                }
                for (int l52 = 0; l52 < 4; ++l52) {
                    l14[0].l1 = (double)-48;
                }
                l42[0].l2 += (byte)l31.l2;
            } else {
                l34 = (double[])l14[0].l13;
            }
        }
        for (int l53 = 0; l53 < 9; ++l53) {
            for (int l54 = 0; l54 < 8; ++l54) {
            }
            l27.l2 *= (byte)(((l42[0].l1 * 5) + l42[0].l1) + -26);
        }
        for (int l55 = 0; l55 < 5; ++l55) {
            Test0 l56 = new Test0();
            double l61 = (double)-30;
            float[] l62 = new float[3];
            double[] l64 = new double[9];
            l49 = (float)(((-35 * l27.l33[0]) * (-8 - 21)) * -6);
            if ((boolean)((byte)l27.l2 < (int)1)) {
                char l57 = (char)45;
                if ((boolean)((Test0)l56 == (Test0)l56)) {
                    char l58 = (char)27;
                    l57 *= (char)-46;
                    l58 -= (char)(((6 + 30) - 1) * 7);
                } else {
                    l15.l13[0] -= (double)(l57 * ((l59 + 49) - 39));
                }
                for (int l60 = 0; l60 < 9; ++l60) {
                }
                l14[0].l17[0] = (double)(((l61 * l14[0].l2) - l42[0].l17[0]) - 3);
            } else {
                l15.l33 = (float[])l15.l33;
                if ((boolean)((double)l56.l1 < (int)1)) {
                    l62 = (float[])l27.l33;
                } else {
                    double l63 = (double)-28;
                    l56.l33[0] += (float)l15.l1;
                    l34[0] = (double)((l63 - (l27.l17[0] + 28)) - -26);
                }
                if ((boolean)((Test0[])l42 == (Test0[])l42)) {
                    l56.l2 *= (byte)(19 - ((-11 * 10) + (-3 + -18)));
                } else {
                    float[] l65 = new float[1];
                    l29.l17 = (double[])l64;
                    l49 += (float)(l42[0].l2 + l14[0].l1);
                    l65 = (float[])l56.l33;
                    l14[0].l1 -= (double)l42[0].l2;
                }
                for (int l66 = 0; l66 < 3; ++l66) {
                }
            }
            for (int l67 = 0; l67 < 4; ++l67) {
                double l69 = (double)42;
                double l72 = (double)-13;
                double l73 = (double)-1;
                Test0 l75 = new Test0();
                for (int l68 = 0; l68 < 8; ++l68) {
                    double l70 = (double)41;
                    double[] l71 = new double[5];
                    l34[0] -= (double)((21 + (l64[0] - l69)) - (l70 + -16));
                    l56.l13 = (double[])l71;
                }
                if ((boolean)((double[])l42[0].l13 == (double[])l42[0].l13)) {
                    l56.l17[0] += (double)(l72 + (l29.l13[0] * l15.l1));
                    l27.l2 -= (byte)l42[0].l2;
                    l15.l1 = (double)(l42[0].l2 - l72);
                    l27.l13[0] = (double)l73;
                } else {
                    Test0 l74 = new Test0();
                    l74 = (Test0)l75;
                    l14[0].l13[0] -= (double)-21;
                }
            }
            l59 -= (double)l59;
        }
        return l29.l1;
    }

    public static void main(String[] args) {
        MainClass t = new MainClass();
        for (int l3 = 0; l3 < 10000; ++l3) {
            double l76 = (double)7;
            l76 = t.method1();
        }
        System.out.println("PASSED");
    }
}
