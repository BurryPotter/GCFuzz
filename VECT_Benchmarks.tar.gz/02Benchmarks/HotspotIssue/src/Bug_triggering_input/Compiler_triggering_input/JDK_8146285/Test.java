package Bug_triggering_input.Compiler_triggering_input.JDK_8146285;
public class Test {
    public static void main(String[] args)
    {
        try { (new byte[-1])[0] = 0; }
        catch (Exception e) { System.out.println(e); }
    }
}