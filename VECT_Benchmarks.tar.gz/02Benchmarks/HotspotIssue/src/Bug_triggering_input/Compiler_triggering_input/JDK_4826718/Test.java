package Bug_triggering_input.Compiler_triggering_input.JDK_4826718;
public class Test {
    public static void main(String[] args) {
Object i = new Integer(0);
        String s = (String)i;
    }
}