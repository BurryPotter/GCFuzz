package Bug_triggering_input.Compiler_triggering_input.JDK_6190413;
public class p {
    public static void main(String[] args) {
        while (true) {
            for (int i = 0; i < args.length; i++) {
                args[i] = new String(args[i]);
            }
        }
    }
}