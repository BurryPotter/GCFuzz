package Bug_triggering_input.Compiler_triggering_input.JDK_6823453;
public class Tester11b
{
    public static void main(String[] args) throws Exception
    {
        long var_1 = -1L;

        short var_2 = (byte) 1.0E10;

        for ( Object temp = new byte[(byte)1.0E10]; true ;
              var_2 = "1".equals("0") ? ((byte) var_1) : 1 )
        {}
    }
}