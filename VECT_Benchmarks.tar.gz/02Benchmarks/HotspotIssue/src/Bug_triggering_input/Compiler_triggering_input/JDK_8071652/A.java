package Bug_triggering_input.Compiler_triggering_input.JDK_8071652;
public class A {
  public static void main(String[] args) {
    new A().add();
    new AA().add();
    new AAA().add();
  }

  public void add() { }
}

class AA {
  public void add() { }  
}


class AAA {
  public void add() { }

}
