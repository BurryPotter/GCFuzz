package Bug_triggering_input.Compiler_triggering_input.JDK_8026328;
public class MainApp {
  public static void main(String[] args) {
    Runnable r = () -> {};
    System.out.println(r.toString());
  }
}
