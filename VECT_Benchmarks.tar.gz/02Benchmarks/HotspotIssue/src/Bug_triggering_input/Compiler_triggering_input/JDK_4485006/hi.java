package Bug_triggering_input.Compiler_triggering_input.JDK_4485006;
public class hi {
    public static void main( String argv[] ) {
        while (true)
            System.out.print( "." );
    }
}