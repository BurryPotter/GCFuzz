package Bug_triggering_input.Compiler_triggering_input.JDK_4833712;
public class HiMom {
    public static void main(String[] args) {
        System.out.println("HiMom!");
    }
}
