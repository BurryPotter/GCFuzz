package Bug_triggering_input.Compiler_triggering_input.JDK_8201447;
public class dowhile {
    public static void main(String[] args) {
        for (int i = 0; i < 10000000; i++) {
            testDoWhile();
        }
    }
    public static volatile boolean repeatLoop;
    static volatile int sideEffect;

    public static void testDoWhile() {
        do {
            sideEffect++;
        } while (repeatLoop);
    }
}
